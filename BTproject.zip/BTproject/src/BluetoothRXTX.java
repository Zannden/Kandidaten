import javax.microedition.io.Connector;
import javax.microedition.io.StreamConnection;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;

public class BluetoothRXTX {
    public static void main(String[] args) {
        String url = "btspp://B827EB418F6D:1;authenticate=false;encrypt=false;master=false";

        StreamConnection conn = null;
        OutputStream out = null;
        InputStream in = null;
        try {
            conn = (StreamConnection) Connector.open(url);
            out = conn.openOutputStream();
            out.write("GO".getBytes());
            out.flush();

            // To receive data
            in = conn.openInputStream();
            int byte_read;
            while ((byte_read = in.read()) != -1) {
                System.out.print((char) byte_read);
            }
        } catch (IOException e) {
            System.err.println("Failed to open connection or output stream: " + e.getMessage());
        } finally {
            if (out != null) {
                try {
                    out.close();
                } catch (IOException e) {
                    System.err.println("Failed to close output stream: " + e.getMessage());
                }
            }
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    System.err.println("Failed to close input stream: " + e.getMessage());
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (IOException e) {
                    System.err.println("Failed to close connection: " + e.getMessage());
                }
            }
        }
    }
}
