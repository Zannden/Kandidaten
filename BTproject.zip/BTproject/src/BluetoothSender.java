import javax.microedition.io.Connector;
import javax.microedition.io.StreamConnection;
import java.io.OutputStream;
import java.io.IOException;

public class BluetoothSender {
    public static void main(String[] args) {
        String url = "btspp://B827EB418F6D:1;authenticate=false;encrypt=false;master=false";

        StreamConnection conn = null;
        OutputStream out = null; // mät pulser till motorer mellan två kors
        try {
            conn = (StreamConnection) Connector.open(url);
            out = conn.openOutputStream();
            out.write("GO".getBytes());
            out.flush();
        } catch (IOException e) {
            System.err.println("Failed to open connection or output stream: " + e.getMessage());
        } finally {
            if (out != null) {
                try {
                    out.close();
                } catch (IOException e) {
                    System.err.println("Failed to close output stream: " + e.getMessage());
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (IOException e) {
                    System.err.println("Failed to close connection: " + e.getMessage());
                }
            }
        }
    }
}
