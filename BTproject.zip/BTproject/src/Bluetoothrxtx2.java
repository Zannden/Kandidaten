import javax.microedition.io.Connector;
import javax.microedition.io.StreamConnection;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.util.Scanner;

public class Bluetoothrxtx2 {
    public static void main(String[] args) {
        String url = "btspp://B827EB418F6D:1;authenticate=false;encrypt=false;master=false";

        StreamConnection conn = null;
        OutputStream out = null;
        InputStream in = null;
        Scanner scanner = null;
        try {
            conn = (StreamConnection) Connector.open(url);
            out = conn.openOutputStream();
            in = conn.openInputStream();

            scanner = new Scanner(System.in);
            while (true) {
                System.out.println("Please enter a command:");
                String command = scanner.nextLine();

                if (command.toLowerCase().equals("a")) {
                    break;
                }

                out.write(command.getBytes());
                out.flush();

                // To receive data
                int byte_read;
                boolean firstLoop = true;

                while ((byte_read = in.read()) != ' ') {
                    if (firstLoop) {
                        System.out.println("Received data:");
                        firstLoop = false;
                    }
                    System.out.print((char) byte_read);
                }

                System.out.println();  // Add a newline

            }
        } catch (IOException e) {
            System.err.println("Failed to open connection or output stream: " + e.getMessage());
        } finally {
            closeResources(conn, out, in, scanner);
        }
    }

    private static void closeResources(StreamConnection conn, OutputStream out, InputStream in, Scanner scanner) {
        if (out != null) {
            try {
                out.close();
            } catch (IOException e) {
                System.err.println("Failed to close output stream: " + e.getMessage());
            }
        }
        if (in != null) {
            try {
                in.close();
            } catch (IOException e) {
                System.err.println("Failed to close input stream: " + e.getMessage());
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (IOException e) {
                System.err.println("Failed to close connection: " + e.getMessage());
            }
        }
        if (scanner != null) {
            scanner.close();
        }
    }
}
